function [L,D,S] = makesimlilarity(X,K)
options = [];
options.NeighborMode = 'KNN';
options.k = K;
options.WeightMode = 'HeatKernel';
options.t = 1;
A = constructW(X,options);
P = diag(sum(A));
L = P - A;
end